// i18n.js - Localization Helper for Flow Chrome Extension
(function () {
    /**
     * Resolves a localized message by key using chrome.i18n.
     * Fallback to the key name if not found.
     */
    function getMessage(key, substitutions) {
        try {
            if (typeof chrome !== 'undefined' && chrome.i18n && typeof chrome.i18n.getMessage === 'function') {
                const msg = chrome.i18n.getMessage(key, substitutions);
                if (msg) return msg;
            }
        } catch (e) { }
        return key;
    }

    /**
     * Translates all elements with data-i18n attributes in the given container.
     */
    function applyI18n(root = document) {
        if (!root || !root.querySelectorAll) return;

        // 1. Text Content
        root.querySelectorAll('[data-i18n]').forEach((el) => {
            const key = el.getAttribute('data-i18n');
            if (key) {
                const text = getMessage(key);
                if (text && text !== key) {
                    el.textContent = text;
                }
            }
        });

        // 2. Placeholder
        root.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
            const key = el.getAttribute('data-i18n-placeholder');
            if (key) {
                const text = getMessage(key);
                if (text && text !== key) {
                    el.placeholder = text;
                }
            }
        });

        // 3. Title
        root.querySelectorAll('[data-i18n-title]').forEach((el) => {
            const key = el.getAttribute('data-i18n-title');
            if (key) {
                const text = getMessage(key);
                if (text && text !== key) {
                    el.title = text;
                }
            }
        });

        // 4. Value (for inputs/buttons)
        root.querySelectorAll('[data-i18n-value]').forEach((el) => {
            const key = el.getAttribute('data-i18n-value');
            if (key) {
                const text = getMessage(key);
                if (text && text !== key) {
                    el.value = text;
                }
            }
        });
    }

    const i18n = {
        getMessage,
        applyI18n
    };

    if (typeof window !== 'undefined') {
        window.i18n = i18n;
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => applyI18n());
        } else {
            applyI18n();
        }
    }

    if (typeof module !== 'undefined' && module.exports) {
        module.exports = i18n;
    }
})();

