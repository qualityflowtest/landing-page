document.addEventListener('DOMContentLoaded', () => {
    const t = (key, subs) => (window.i18n && typeof window.i18n.getMessage === 'function') 
        ? window.i18n.getMessage(key, subs) 
        : key;

    // Custom Toast for Popup (replaces blocking alerts)
    function showPopupToast(msg, isError = false) {
        let toast = document.getElementById('popupToast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'popupToast';
            toast.style.cssText = "position:fixed; top:10px; left:50%; transform:translateX(-50%); padding:8px 12px; border-radius:6px; color:#fff; font-size:13px; font-weight:600; text-align:center; z-index:99999; opacity:0; transition:opacity 0.3s ease; width:90%; box-sizing:border-box; box-shadow:0 4px 6px rgba(0,0,0,0.1);";
            document.body.appendChild(toast);
        }
        toast.style.background = isError ? '#ef4444' : '#10b981';
        toast.textContent = msg;
        toast.style.opacity = '1';
        setTimeout(() => { toast.style.opacity = '0'; }, 3000);
    }

    // Elements - Record View
    const recordView = document.getElementById('recordView');
    const toggleBtn = document.getElementById('toggleBtn');
    const statusText = document.getElementById('statusText');
    const statusContainer = document.getElementById('statusContainer');
    const clearBtn = document.getElementById('clearBtn');
    const goToSaveBtn = document.getElementById('goToSaveBtn');
    const nodeNameInput = document.getElementById('nodeNameInput');

    // Step Elements
    const stepIdleState = document.getElementById('stepIdleState');
    const stepActiveState = document.getElementById('stepActiveState');
    const startStepBtn = document.getElementById('startStepBtn');
    const concludeStepBtn = document.getElementById('concludeStepBtn');
    const currentStepNameDisplay = document.getElementById('currentStepNameDisplay');

    // Elements - Save View
    const saveView = document.getElementById('saveView');
    const productSelect = document.getElementById('productSelect');
    const featureSelect = document.getElementById('featureSelect');
    const confirmSendBtn = document.getElementById('confirmSendBtn');
    const cancelSaveBtn = document.getElementById('cancelSaveBtn');
    const authStatus = document.getElementById('authStatus');

    // State
    let hierarchy = [];
    let hierarchyLoaded = false;

    // --- UI HELPERS ---

    function showView(viewName) {
        if (viewName === 'record') {
            recordView.classList.add('active');
            saveView.classList.remove('active');
        } else {
            recordView.classList.remove('active');
            saveView.classList.add('active');
            if (!hierarchyLoaded) loadHierarchy();

            // Render Preview
            chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
                renderNodesPreview(response ? response.interactions || [] : []);
            });
        }
    }

    // Safe DOM-based preview rendering (Zero DOM-XSS)
    function renderNodesPreview(interactions) {
        const container = document.getElementById('nodesList');
        const previewSection = document.getElementById('nodesPreview');

        if (!interactions || interactions.length === 0) {
            previewSection.style.display = 'none';
            return;
        }

        previewSection.style.display = 'block';
        container.replaceChildren();

        // Group by Node Name
        const groups = {};
        interactions.forEach(i => {
            let name = i.customNodeName;
            if (!name) name = i.pageTitle || t("unknownPage");

            if (!groups[name]) groups[name] = { count: 0, url: i.pageUrl };
            groups[name].count++;
        });

        // Render Groups using safe DOM methods
        Object.keys(groups).forEach(name => {
            const data = groups[name];
            const div = document.createElement('div');
            div.style.cssText = "background: rgba(15, 23, 42, 0.7); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 8px; padding: 10px 12px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;";

            const textWrap = document.createElement('div');
            textWrap.style.overflow = "hidden";
            textWrap.style.marginRight = "8px";

            const nameEl = document.createElement('div');
            nameEl.style.cssText = "font-size: 13px; font-weight: 600; color: #f8fafc; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 200px;";
            nameEl.title = name;
            nameEl.textContent = name;

            const urlEl = document.createElement('div');
            urlEl.style.cssText = "font-size: 11px; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 200px;";
            urlEl.title = data.url || '';
            urlEl.textContent = data.url || '';

            textWrap.appendChild(nameEl);
            textWrap.appendChild(urlEl);

            const badge = document.createElement('div');
            badge.style.cssText = "background: rgba(14, 165, 233, 0.2); border: 1px solid rgba(14, 165, 233, 0.4); color: #38bdf8; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 12px; flex-shrink: 0;";
            badge.textContent = `${data.count} ${t("interactionsCount")}`;

            div.appendChild(textWrap);
            div.appendChild(badge);
            container.appendChild(div);
        });
    }

    function updateRecordingUI(isRecording, interactionCount = 0) {
        if (statusText) statusText.textContent = isRecording ? t("statusRecording") : t("statusReady");
        if (statusContainer) statusContainer.classList.toggle('recording', isRecording);
        if (toggleBtn) {
            toggleBtn.textContent = isRecording ? t("btnStopRecording") : t("btnStartRecording");
            toggleBtn.className = isRecording ? 'btn btn-danger' : 'btn btn-primary';
        }

        const interactionCounter = document.getElementById('interactionCounter');
        const interactionCountDisplay = document.getElementById('interactionCount');
        if (interactionCounter && interactionCountDisplay) {
            interactionCountDisplay.textContent = String(interactionCount);
            interactionCounter.style.display = interactionCount > 0 ? 'flex' : 'none';
        }

        if (goToSaveBtn) goToSaveBtn.style.display = (!isRecording && interactionCount > 0) ? 'block' : 'none';
        if (clearBtn) clearBtn.style.display = (!isRecording && interactionCount > 0) ? 'block' : 'none';

        const controlContainer = document.getElementById('stepControlContainer');
        if (controlContainer) {
            controlContainer.style.opacity = isRecording ? '1' : '0.5';
            controlContainer.style.pointerEvents = isRecording ? 'auto' : 'none';
        }

        if (authStatus) {
            const hasToken = !!(window.currentAuthToken);
            authStatus.textContent = hasToken ? t("authStatusActive") : t("authStatusPending");
            authStatus.className = hasToken ? 'auth-badge authenticated' : 'auth-badge unauthenticated';
        }
    }

    function updateStepUI(currentStepName) {
        if (currentStepName) {
            stepIdleState.style.display = 'none';
            stepActiveState.style.display = 'block';
            currentStepNameDisplay.textContent = currentStepName;
        } else {
            stepIdleState.style.display = 'block';
            stepActiveState.style.display = 'none';
            currentStepNameDisplay.textContent = "";
        }
    }

    let lastStepsSummarySignature = "";

    // Safe DOM-based steps summary rendering (Zero DOM-XSS)
    function updateStepsSummary(interactions = [], completedSteps = []) {
        const container = document.getElementById('stepsSummary');
        if (!container) return;

        const groups = {};

        // 1. Include explicitly completed step names
        if (Array.isArray(completedSteps)) {
            completedSteps.forEach(stepName => {
                if (stepName && !groups[stepName]) {
                    groups[stepName] = { inters: 0 };
                }
            });
        }

        // 2. Count interactions per step
        if (Array.isArray(interactions)) {
            interactions.forEach(i => {
                const name = i.customNodeName || t("generalStep");
                if (!groups[name]) groups[name] = { inters: 0 };
                groups[name].inters++;
            });
        }

        const totalSteps = Object.keys(groups).length;
        const totalCountBadge = document.getElementById('stepsTotalCountBadge');
        if (totalCountBadge) {
            totalCountBadge.textContent = totalSteps > 0 ? `(${totalSteps})` : '';
        }

        // Avoid re-rendering DOM if data has not changed (prevents blinking/flickering)
        const signature = JSON.stringify({ totalSteps, groups });
        if (signature === lastStepsSummarySignature) {
            return;
        }
        lastStepsSummarySignature = signature;

        container.replaceChildren();
        if (totalSteps === 0) {
            const emptyEl = document.createElement('div');
            emptyEl.style.cssText = "color:#94a3b8; font-size:12px; padding: 6px 0; text-align: center;";
            emptyEl.textContent = t("noStepsRecorded");
            container.appendChild(emptyEl);
            return;
        }

        Object.keys(groups).forEach(name => {
            const stats = groups[name];
            const row = document.createElement('div');
            row.className = 'step-item';
            row.style.cssText = "display:flex; justify-content:space-between; align-items:center; padding:8px 12px; background:rgba(15, 23, 42, 0.7); border:1px solid rgba(255, 255, 255, 0.12); border-radius:10px; margin-bottom:6px; box-shadow: 0 2px 4px rgba(0,0,0,0.15);";

            const leftWrap = document.createElement('div');
            leftWrap.style.cssText = "display:flex; align-items:center; gap:8px; flex:1; min-width:0; margin-right:8px;";

            const icon = document.createElement('span');
            icon.style.cssText = "color:#10b981; font-size:12px; font-weight:bold; flex-shrink:0;";
            icon.textContent = "✓";

            const nameDiv = document.createElement('div');
            nameDiv.style.cssText = "font-weight:600; font-size:13px; color:#f8fafc; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;";
            nameDiv.textContent = name;
            nameDiv.title = name;

            leftWrap.appendChild(icon);
            leftWrap.appendChild(nameDiv);

            const badgeWrap = document.createElement('div');
            badgeWrap.style.cssText = "display:flex; gap:6px; flex-shrink:0;";

            const badge = document.createElement('span');
            badge.style.cssText = "background:rgba(139, 92, 246, 0.2); border:1px solid rgba(139, 92, 246, 0.4); color:#c4b5fd; padding:3px 8px; border-radius:12px; font-size:11px; font-weight:600;";
            badge.textContent = `${stats.inters} ${t("interactionsCount")}`;

            badgeWrap.appendChild(badge);
            row.appendChild(leftWrap);
            row.appendChild(badgeWrap);
            container.appendChild(row);
        });
    }

    // --- LOGIC ---

    // 1. Initial Sync
    chrome.runtime.sendMessage({ type: "GET_STATUS" }, async (response) => {
        if (!response) {
            console.error("[Flow Popup] No status response from background!");
            return;
        }
        const config = await getConfig();
        window.currentAuthToken = config.TOKEN || response.authToken;
        updateRecordingUI(response.isRecording, response.interactionCount);
        updateStepUI(response.currentNodeName);
        updateStepsSummary(response.interactions || [], response.completedSteps || []);

        if (!hierarchyLoaded && window.currentAuthToken) {
            loadHierarchy();
        }
    });

    // 2. Reactive Storage Listener (Instant state synchronization)
    if (chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener(async (changes, areaName) => {
            const config = await getConfig();
            window.currentAuthToken = config.TOKEN || (await chrome.storage.local.get(['authToken'])).authToken;
            
            chrome.runtime.sendMessage({ type: "GET_STATUS" }, (res) => {
                if (res) {
                    if (recordView && recordView.classList.contains('active')) {
                        updateRecordingUI(res.isRecording, res.interactionCount || 0);
                        updateStepsSummary(res.interactions || [], res.completedSteps || []);
                        updateStepUI(res.currentNodeName);
                    }
                }
            });
        });
    }

    // Polling fallback
    setInterval(async () => {
        const config = await getConfig();
        chrome.runtime.sendMessage({ type: "GET_STATUS" }, (res) => {
            if (res) {
                window.currentAuthToken = config.TOKEN || res.authToken;
                if (recordView && recordView.classList.contains('active')) {
                    updateRecordingUI(res.isRecording, res.interactionCount || 0);
                    updateStepsSummary(res.interactions || [], res.completedSteps || []);
                    updateStepUI(res.currentNodeName);
                }
            }
        });
    }, 1500);

    // 3. Step Controls
    startStepBtn.addEventListener('click', () => {
        const name = nodeNameInput.value.trim();
        if (!name) return;
        chrome.runtime.sendMessage({ type: "SET_NODE_NAME", name: name }, () => {
            updateStepUI(name);
            nodeNameInput.value = "";
        });
    });

    concludeStepBtn.addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: "SET_NODE_NAME", name: "" }, () => {
            updateStepUI("");
            chrome.runtime.sendMessage({ type: "GET_STATUS" }, (statusRes) => {
                if (statusRes) {
                    updateStepsSummary(statusRes.interactions || [], statusRes.completedSteps || []);
                }
            });
        });
    });

    // 4. Recording Controls
    toggleBtn.addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: "GET_STATUS" }, (status) => {
            if (!status) return;
            if (status.isRecording) {
                chrome.runtime.sendMessage({ type: "STOP_RECORDING" }, (res) => {
                    const finalCount = res ? res.count : 0;
                    updateRecordingUI(false, finalCount);
                    chrome.runtime.sendMessage({ type: "GET_STATUS" }, (statusRes) => {
                        if (statusRes) {
                            updateStepsSummary(statusRes.interactions || [], statusRes.completedSteps || []);
                        }
                    });
                });
            } else {
                chrome.runtime.sendMessage({ type: "START_RECORDING" }, () => {
                    updateRecordingUI(true, 0);
                    lastStepsSummarySignature = "";
                    updateStepsSummary([], []);
                });
            }
        });
    });

    clearBtn.addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: "CLEAR_DATA" }, () => {
            updateRecordingUI(false, 0);
            lastStepsSummarySignature = "";
            updateStepsSummary([], []);
        });
    });

    goToSaveBtn.addEventListener('click', () => showView('save'));
    cancelSaveBtn.addEventListener('click', () => showView('record'));

    // Open Options Page
    const openOptionsBtn = document.getElementById('openOptionsBtn');
    if (openOptionsBtn) {
        openOptionsBtn.addEventListener('click', (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: 'options.html' });
        });
    }

    // 5. Backend Integration
    async function loadHierarchy() {
        productSelect.replaceChildren();
        const loadingOpt = document.createElement('option');
        loadingOpt.textContent = t("selectLoading");
        productSelect.appendChild(loadingOpt);

        const config = await getConfig();
        const baseUrl = config.API_BASE_URL;

        const headers = {};
        if (config.TOKEN) {
            headers['Authorization'] = `Bearer ${config.TOKEN}`;
        }

        fetch(`${baseUrl}/capture/structure`, { headers })
            .then(res => res.json())
            .then(data => {
                hierarchy = Array.isArray(data) ? data : [];
                productSelect.replaceChildren();
                const defaultOpt = document.createElement('option');
                defaultOpt.value = "";
                defaultOpt.textContent = t("selectPlaceholder");
                productSelect.appendChild(defaultOpt);

                hierarchy.forEach(prod => {
                    const opt = document.createElement('option');
                    opt.value = String(prod.id);
                    opt.textContent = prod.name;
                    productSelect.appendChild(opt);
                });
                hierarchyLoaded = true;
            })
            .catch(err => {
                console.error("[Flow] Failed to load hierarchy:", err);
                productSelect.replaceChildren();
                const errOpt = document.createElement('option');
                errOpt.textContent = t("toastConnectionError") + (err.message || "");
                productSelect.appendChild(errOpt);
            });
    }

    productSelect.addEventListener('change', (e) => {
        const prodId = parseInt(e.target.value);
        featureSelect.replaceChildren();
        const defaultOpt = document.createElement('option');
        defaultOpt.value = "";
        defaultOpt.textContent = t("selectPlaceholder");
        featureSelect.appendChild(defaultOpt);
        featureSelect.disabled = true;

        if (prodId) {
            const product = hierarchy.find(p => p.id === prodId);
            if (product && product.features && Array.isArray(product.features)) {
                product.features.forEach(feat => {
                    const opt = document.createElement('option');
                    opt.value = String(feat.id);
                    opt.textContent = feat.name;
                    featureSelect.appendChild(opt);
                });
                featureSelect.disabled = false;
            }
        }
    });

    confirmSendBtn.addEventListener('click', () => {
        const featureId = featureSelect.value;
        if (!featureId) {
            showPopupToast(t("toastSelectProjectFeature"), true);
            return;
        }

        confirmSendBtn.textContent = t("btnSending");
        confirmSendBtn.disabled = true;

        chrome.runtime.sendMessage({ type: "GET_STATUS" }, async (response) => {
            if (!response) {
                showPopupToast(t("toastConnectionError"), true);
                confirmSendBtn.disabled = false;
                confirmSendBtn.textContent = t("btnConfirmSend");
                return;
            }

            const interactions = response.interactions || [];
            if (interactions.length === 0) {
                showPopupToast(t("toastNoInteractions"), true);
                confirmSendBtn.disabled = false;
                confirmSendBtn.textContent = t("btnConfirmSend");
                return;
            }

            const data = {
                requests: response.requests || [],
                interactions: interactions
            };

            const json = JSON.stringify(data, null, 2);
            const config = await getConfig();
            const baseUrl = config.API_BASE_URL;

            const saveName = response.currentNodeName || `Gravação ${new Date().toLocaleTimeString()}`;
            const nameParam = `&name=${encodeURIComponent(saveName)}`;

            const headers = { 
                'Content-Type': 'application/json' 
            };

            const finalToken = config.TOKEN || window.currentAuthToken;
            if (finalToken) {
                headers['Authorization'] = `Bearer ${finalToken}`;
            }

            fetch(`${baseUrl}/front-recording/save?project_id=${featureId}${nameParam}`, {
                method: 'POST',
                headers: headers,
                body: json
            }).then(async (res) => {
                if (res.ok) {
                    showPopupToast(t("toastSaveSuccess"));
                    chrome.runtime.sendMessage({ type: "CLEAR_DATA" }, () => {
                        updateRecordingUI(false, 0);
                        showView('record');
                        confirmSendBtn.textContent = t("btnConfirmSend");
                        confirmSendBtn.disabled = false;
                    });
                } else {
                    const errData = await res.json().catch(() => ({}));
                    const msg = errData.detail || errData.error || "Erro no servidor";
                    showPopupToast(t("toastSaveError") + msg, true);
                    confirmSendBtn.textContent = t("btnConfirmSend");
                    confirmSendBtn.disabled = false;
                }
            }).catch(err => {
                showPopupToast(t("toastConnectionError") + err.message, true);
                confirmSendBtn.textContent = t("btnConfirmSend");
                confirmSendBtn.disabled = false;
            });
        });
    });
});
