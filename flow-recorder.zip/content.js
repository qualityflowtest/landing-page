(() => {
    // content.js - Pure Relay & Secure Token Detector
    if (window.__FLOW_RECORDER_CONTENT_ACTIVE__) {
        return;
    }
    window.__FLOW_RECORDER_CONTENT_ACTIVE__ = true;

    console.log("[Flow Recorder] Relay active.");

    function getLabels() {
        return {
            recording: (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getMessage("statusRecording")) || "Recording...",
            validationAdded: (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getMessage("toastValidationAdded")) || "Validation added: ",
            titleCaptured: (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getMessage("toastTitleCaptured")) || "Title captured: ",
            modalCaptured: (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getMessage("toastModalCaptured")) || "Modal captured: "
        };
    }

    // Secure Token Detection: Only on authorized Flow origins configured in extension settings
    try {
        chrome.storage.sync.get(['apiUrl'], (items) => {
            if (!items || !items.apiUrl) return;
            try {
                const apiHost = new URL(items.apiUrl).hostname;
                const currentHost = window.location.hostname;
                const isAuthorizedOrigin = currentHost === apiHost ||
                    (currentHost === 'localhost' && (apiHost === 'localhost' || apiHost === '127.0.0.1')) ||
                    (currentHost === '127.0.0.1' && (apiHost === 'localhost' || apiHost === '127.0.0.1'));

                if (isAuthorizedOrigin) {
                    const token = localStorage.getItem('token');
                    if (token && typeof token === 'string' && token.trim().length > 10) {
                        chrome.runtime.sendMessage({ type: "SET_TOKEN", token: token.trim() });
                    }
                }
            } catch (_) { }
        });
    } catch (_) { }

    // Only relay messages - Avoid doing injection here to prevent double injection with background script
    window.addEventListener("message", (event) => {
        if (event.source !== window || !event.data || !event.data.type) return;

        if (event.data.type === "FLOW_CAPTURE_INTERACTION" || event.data.type === "FLOW_CAPTURE_REQUEST") {
            const msgType = event.data.type === "FLOW_CAPTURE_INTERACTION" ? "NEW_INTERACTION" : "NEW_REQUEST";
            try {
                chrome.runtime.sendMessage({
                    type: msgType,
                    data: event.data.data
                });
            } catch (e) { }
        }

        if (event.data.type === "FLOW_INJECTOR_PING") {
            chrome.storage.local.get(['isRecording'], (res) => {
                if (res && res.isRecording) {
                    window.postMessage({ type: "FLOW_RECORDER_ENABLE", labels: getLabels() }, "*");
                }
            });
        }
    });

    // Relay control signals
    chrome.runtime.onMessage.addListener((msg) => {
        if (msg.type === "ENABLE_INTERCEPTOR") {
            window.postMessage({ type: "FLOW_RECORDER_ENABLE", labels: getLabels() }, "*");
        } else if (msg.type === "DISABLE_INTERCEPTOR") {
            window.postMessage({ type: "FLOW_RECORDER_STOP" }, "*");
        }
        return true;
    });
})();
