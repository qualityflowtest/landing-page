// inject.js - MAIN world source (V2.0.0 - ROBUST SELECTORS)
(function () {
    if (window.__FLOW_RECORDER_V200__) return;
    window.__FLOW_RECORDER_V200__ = true;

    let isRecording = false;
    let lastClickAt = 0;
    let apiCallCounts = {}; // Track frequency per URL

    let recorderLabels = {
        recording: "GRAVANDO",
        validationAdded: "Validação adicionada: ",
        titleCaptured: "Título capturado: ",
        modalCaptured: "Modal capturado: "
    };

    const isTopFrame = window.self === window.top;
    const contextName = isTopFrame ? "PRINCIPAL" : "IFRAME";

    console.log(`%c[Flow] V2.0.0 - MONITOR ${contextName} ATIVO (Seletores Robustos)`, "color:#fff; background:#ec4899; padding:4px 10px; border-radius:10px; font-weight:bold;");

    const setBanner = (active) => {
        if (!isTopFrame) return; // Only show banner on top frame
        let b = document.getElementById('flow-status-indicator');
        if (active) {
            if (!b) {
                b = document.createElement('div');
                b.id = 'flow-status-indicator';
                b.setAttribute('data-flow-recorder', 'true');
                b.style.cssText = "position:fixed; top:5px; right:5px; height:24px; padding:0 12px; background:#ef4444; color:white; border-radius:12px; display:flex; align-items:center; font-family:sans-serif; font-size:12px; font-weight:bold; z-index:99999999; pointer-events:none; box-shadow:0 2px 5px rgba(0,0,0,0.3);";
                
                const dot = document.createElement('span');
                dot.style.marginRight = '6px';
                dot.textContent = '🔴';

                const textSpan = document.createElement('span');
                textSpan.id = 'flow-status-indicator-text';
                textSpan.textContent = (recorderLabels.recording || 'GRAVANDO').toUpperCase();

                b.appendChild(dot);
                b.appendChild(textSpan);
                document.body ? document.body.appendChild(b) : document.documentElement.appendChild(b);
            } else {
                const textSpan = document.getElementById('flow-status-indicator-text');
                if (textSpan) {
                    textSpan.textContent = (recorderLabels.recording || 'GRAVANDO').toUpperCase();
                }
            }
        } else if (b) b.remove();
    };
    
    function showToast(msg, isSuccess = true) {
        if (!isTopFrame) {
            window.parent.postMessage({ type: "FLOW_SHOW_TOAST", msg, isSuccess }, "*");
            return;
        }
        const t = document.createElement('div');
        t.setAttribute('data-flow-recorder', 'true');
        t.style.cssText = `position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:${isSuccess ? '#10b981' : '#f59e0b'}; color:white; padding:8px 16px; border-radius:8px; font-family:sans-serif; font-size:13px; font-weight:bold; z-index:99999999; pointer-events:none; box-shadow:0 4px 12px rgba(0,0,0,0.15); opacity:0; transition:opacity 0.3s ease;`;
        t.textContent = msg;
        document.body.appendChild(t);
        requestAnimationFrame(() => t.style.opacity = '1');
        setTimeout(() => {
            t.style.opacity = '0';
            setTimeout(() => t.remove(), 300);
        }, 2000);
    }

    window.addEventListener("message", (e) => {
        if (e.source !== window && e.data?.type === "FLOW_SHOW_TOAST") {
            showToast(e.data.msg, e.data.isSuccess);
        }
    });

    window.postMessage({ type: "FLOW_INJECTOR_PING" }, "*");

    window.addEventListener("message", (e) => {
        if (e.source !== window || !e.data) return;
        if (e.data.type === "FLOW_RECORDER_ENABLE") {
            isRecording = true;
            apiCallCounts = {};
            if (e.data.labels) {
                recorderLabels = { ...recorderLabels, ...e.data.labels };
            }
            setBanner(true);
        } else if (e.data.type === "FLOW_RECORDER_STOP") {
            isRecording = false;
            apiCallCounts = {};
            setBanner(false);
        }
    });

    async function normalizeBody(body) {
        if (!body) return null;
        try {
            if (typeof body === 'string') return body;
            if (body instanceof URLSearchParams) return body.toString();
            if (body instanceof FormData) {
                const obj = {};
                body.forEach((v, k) => { obj[k] = (v instanceof File) ? `[File: ${v.name}]` : v; });
                return JSON.stringify(obj);
            }
            if (body instanceof Blob) return await body.text();
            if (body instanceof ArrayBuffer) return new TextDecoder().decode(body);
            if (typeof body === 'object') return JSON.stringify(body);
            return String(body);
        } catch (e) { return "[Corpo não legível]"; }
    }

    const cleanText = (str) => str ? str.replace(/["\n]/g, '').trim() : '';

    // Helper: Extract human-readable label from element, its attributes, or its shadow root
    const extractFieldLabel = (element) => {
        if (!element) return '';
        // 1. Explicit label attribute on custom element (e.g. Vaadin, Shoelace)
        const attrLabel = element.getAttribute('label');
        if (attrLabel && attrLabel.trim().length > 1) return cleanText(attrLabel);

        // 2. Aria-label or placeholder
        const aria = element.getAttribute('aria-label');
        if (aria && aria.trim().length > 1) return cleanText(aria);

        const ph = element.getAttribute('placeholder');
        if (ph && ph.trim().length > 1) return cleanText(ph);

        // 3. Label inside Shadow DOM (Vaadin, Web Components)
        if (element.shadowRoot) {
            const sLabel = element.shadowRoot.querySelector('[part~="label"], label, .label');
            if (sLabel && sLabel.innerText?.trim()) {
                return cleanText(sLabel.innerText);
            }
            const sInput = element.shadowRoot.querySelector('input, textarea, select');
            if (sInput) {
                const sPh = sInput.getAttribute('placeholder') || sInput.getAttribute('aria-label');
                if (sPh && sPh.trim().length > 1) return cleanText(sPh);
            }
        }

        // 4. Document label by ID
        if (element.id && !/^\d/.test(element.id) && !/[a-f0-9]{20,}/.test(element.id)) {
            const label = document.querySelector(`label[for="${element.id}"]`);
            if (label && label.innerText) return cleanText(label.innerText);
        }

        // 5. Parent label
        const pLabel = element.closest('label');
        if (pLabel && pLabel.innerText) return cleanText(pLabel.innerText);

        // 6. Element innerText if short (e.g. checkbox)
        if (element.innerText && element.innerText.trim().length > 1 && element.innerText.trim().length < 60) {
            return cleanText(element.innerText);
        }

        return '';
    };

    // Playwright Semantic Selector Generation - ENTERPRISE RELIABILITY
    function getBestSelector(el) {
        if (!el || el === document) return "document";

        const tag = el.tagName.toLowerCase();

        // Helper: Check uniqueness for standard CSS selectors
        const isUniqueCSS = (selector) => {
            try { return document.querySelectorAll(selector).length === 1; } 
            catch (e) { return false; }
        };

        // 1. Data-Attributes (Gold standard)
        const testAttrs = ['data-testid', 'data-qa', 'data-cy', 'data-id', 'test-id', 'data-automation'];
        for (const attr of testAttrs) {
            const val = el.getAttribute(attr);
            if (val) {
                const s = `[${attr}="${val}"]`;
                if (isUniqueCSS(s)) return s;
            }
        }

        // 2. Playwright Semantic Roles and Labels (High Resilience)
        // Note: Playwright supports `internal:role=button[name="Submit"i]`.
        // The recorder backend must convert these, but if we emit standard Playwright strings, the backend natively supports it!

        const isButton = ['button', 'a'].includes(tag) || tag.includes('button') || el.getAttribute('role') === 'button';
        const isCheckbox = tag.includes('checkbox') || el.getAttribute('type') === 'checkbox';
        const isOption = ['option', 'vaadin-item', 'vaadin-combo-box-item'].includes(tag) || tag.includes('item') || el.getAttribute('role') === 'option' || el.classList.contains('dropdown-item');
        const isFormField = !isButton && !isOption && (['input', 'textarea', 'select'].includes(tag) || tag.includes('-') || (el.shadowRoot && el.shadowRoot.querySelector('input, textarea, select')));

        // Dropdown / Select Options (Native or Custom / Web Component)
        if (isOption) {
            let optText = cleanText(el.innerText || el.textContent || el.getAttribute('label') || el.value || '');
            if (optText && optText.length > 0 && optText.length < 80) {
                return `internal:role=option[name="${optText}"i]`;
            }
        }

        if (isCheckbox) {
            if (el.id && !/^\d/.test(el.id) && !/[a-f0-9]{20,}/.test(el.id)) {
                const s = `#${CSS.escape(el.id)}`;
                if (isUniqueCSS(s)) return s;
            }
            const name = el.getAttribute('name');
            if (name && isUniqueCSS(`${tag}[name="${name}"]`)) {
                return `${tag}[name="${name}"]`;
            }
            const fieldLabel = extractFieldLabel(el);
            if (fieldLabel && fieldLabel.length > 1 && fieldLabel.length < 150) {
                return `internal:label="${fieldLabel}"i`;
            }
            if (tag.includes('-') && isUniqueCSS(tag)) {
                return tag;
            }
        }

        // Form Fields (Inputs, Textareas, Selects, and Custom Web Component Fields)
        if (isFormField) {
            if (el.id && !/^\d/.test(el.id) && !/[a-f0-9]{20,}/.test(el.id)) {
                const s = `#${CSS.escape(el.id)}`;
                if (isUniqueCSS(s)) return s;
            }
            const fieldLabel = extractFieldLabel(el);
            if (fieldLabel && fieldLabel.length > 1 && fieldLabel.length < 80) {
                return `internal:label="${fieldLabel}"i`;
            }

            // A. Placeholder
            const ph = el.getAttribute('placeholder') || el.shadowRoot?.querySelector('input, textarea')?.getAttribute('placeholder');
            if (ph && ph.length > 2) {
                const phClean = cleanText(ph);
                const s = `[placeholder="${phClean}"]`;
                if (isUniqueCSS(s)) return s;
            }

            // B. Name attribute
            const name = el.getAttribute('name') || el.shadowRoot?.querySelector('input, textarea, select')?.getAttribute('name');
            if (name && name.length > 2) {
                const s = `${tag}[name="${name}"]`;
                if (isUniqueCSS(s)) return s;
            }

            if (tag.includes('-') && isUniqueCSS(tag)) {
                return tag;
            }
        }

        // 3. Aria Labels (Accessbility)
        const aria = el.getAttribute('aria-label');
        if (aria && aria.length > 1 && aria.length < 50) {
            const aClean = cleanText(aria);
            return `internal:label="${aClean}"i`;
        }

        // 4. Buttons and Links by Text
        if (isButton) {
            let text = el.innerText?.trim();
            if (!text && el.value) text = el.value.trim();
            if (!text && el.getAttribute('aria-label')) text = el.getAttribute('aria-label').trim();
            if (text && text.length > 1 && text.length < 50) {
                const tClean = cleanText(text);
                
                const elements = Array.from(document.querySelectorAll(tag)).filter(e => {
                    let eText = e.innerText?.trim() || e.value?.trim() || e.getAttribute('aria-label')?.trim();
                    return eText === text;
                });
                
                if (elements.length === 1 && elements[0] === el) {
                    return `internal:role=${tag === 'a' ? 'link' : 'button'}[name="${tClean}"i]`;
                }
                
                let p = el.parentElement;
                let depth = 0;
                while(p && depth < 4) {
                    if (p.id && !/^\d/.test(p.id) && !/[a-f0-9]{20,}/.test(p.id)) {
                        return `#${CSS.escape(p.id)} >> internal:role=${tag === 'a' ? 'link' : 'button'}[name="${tClean}"i]`;
                    }
                    p = p.parentElement;
                    depth++;
                }
                
                return `internal:role=${tag === 'a' ? 'link' : 'button'}[name="${tClean}"i]`;
            }
        }

        // 5. General Text Elements (Headings, Spans)
        if (['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p', 'li'].includes(tag)) {
            let text = el.innerText?.trim();
            if (text && text.length > 1 && text.length < 50) {
                const tClean = cleanText(text);
                const elements = Array.from(document.querySelectorAll(tag)).filter(e => (e.innerText?.trim() === text));
                if (elements.length === 1 && elements[0] === el) {
                    return `internal:text="${tClean}"s`;
                }
            }
        }

        // 6. Stable ID
        if (el.id && !/^\d/.test(el.id)) {
            const isDynamic = /[a-f0-9]{20,}/.test(el.id) || /\d{5,}/.test(el.id);
            if (!isDynamic) {
                const s = `#${CSS.escape(el.id)}`;
                if (isUniqueCSS(s)) return s;
            }
        }

        // 7. Scoped CSS Fallback (Avoiding nth-child when possible)
        let pathList = [];
        let curr = el;
        while (curr && curr.nodeType === Node.ELEMENT_NODE && curr.tagName !== 'BODY' && curr.tagName !== 'HTML') {
            let selector = curr.tagName.toLowerCase();

            if (curr.id && !/^\d/.test(curr.id) && !/[a-f0-9]{20,}/.test(curr.id)) {
                selector = `#${CSS.escape(curr.id)}`;
                pathList.unshift(selector);
                const full = pathList.join(" >> ");
                if (isUniqueCSS(full)) return full;
                break;
            } else {
                if (curr.className && typeof curr.className === 'string' && curr.className.trim().length > 0) {
                    const classes = curr.className.trim().split(/\s+/).filter(c => !/\d/.test(c) && !c.includes(':') && c.length > 2);
                    if (classes.length > 0) {
                        selector += `.${classes[0]}`;
                    }
                }

                let tempPath = [selector, ...pathList].join(" >> ");
                if (isUniqueCSS(tempPath)) {
                    pathList.unshift(selector);
                    return pathList.join(" >> ");
                }

                let index = 1;
                let sib = curr.previousElementSibling;
                while (sib) {
                    index++;
                    sib = sib.previousElementSibling;
                }
                
                if (curr.previousElementSibling || curr.nextElementSibling) {
                    selector += `:nth-child(${index})`;
                }
            }

            pathList.unshift(selector);
            const currentFull = pathList.join(" >> ");
            if (isUniqueCSS(currentFull)) return currentFull;

            curr = curr.parentElement;
            if (pathList.length > 6) break;
        }

        return pathList.join(" >> ");
    }

    // Capture Interaction (Relay to Background)
    function captureInteraction(data) {
        window.postMessage({ type: "FLOW_CAPTURE_INTERACTION", data: { ...data, context: contextName, isIframe: !isTopFrame, frameUrl: window.location.href } }, "*");
    }

    // Capture Request (Relay to Background)
    function captureRequest(data) {
        const urlKey = data.url.split('?')[0];
        apiCallCounts[urlKey] = (apiCallCounts[urlKey] || 0) + 1;

        console.log(`%c[Flow] API (${contextName} - Chamada #${apiCallCounts[urlKey]}): %c${data.method} ${data.url}`,
            "color:#ec4899; font-weight:bold;", "color:#334155;",
            { headers: data.headers, body: data.body });

        window.postMessage({ type: "FLOW_CAPTURE_REQUEST", data: { ...data, callIndex: apiCallCounts[urlKey], context: contextName } }, "*");
    }

    // Listeners
    // 1. Mouse Hover Highlight
    let hoveredElement = null;
    let originalOutline = "";
    
    document.addEventListener('mouseover', (e) => {
        if (!isRecording) return;
        const path = (e.composedPath && e.composedPath()) || [];
        const inner = path[0] || e.target;
        let el = e.target.closest('button, a, input, select, textarea, [role="button"], [onclick], span, p, h1, h2, h3, h4, h5, h6, label, li');
        if (!el && e.target?.tagName?.includes('-')) el = e.target;
        if (!el && inner && inner.closest) el = inner.closest('button, a, input, select, textarea, [role="button"], [onclick], span, p, h1, h2, h3, h4, h5, h6, label, li');
        if (!el || el === document.body || el === document.documentElement) return;
        if (window.getComputedStyle(el).pointerEvents === 'none') return;
        
        if (hoveredElement && hoveredElement !== el) {
            hoveredElement.style.outline = originalOutline;
        }
        
        hoveredElement = el;
        originalOutline = el.style.outline;
        el.style.outline = "2px solid #ec4899";
        el.style.outlineOffset = "-2px";
    }, true);

    document.addEventListener('mouseout', (e) => {
        if (!isRecording || !hoveredElement) return;
        hoveredElement.style.outline = originalOutline;
        hoveredElement = null;
    }, true);

    // 2. Click Recording
    document.addEventListener('click', (e) => {
        if (!isRecording) return;
        
        // Remove highlight immediately on click
        if (hoveredElement) {
            hoveredElement.style.outline = originalOutline;
            hoveredElement = null;
        }

        const now = Date.now();
        const path = (e.composedPath && e.composedPath()) || [];
        const inner = path[0] || e.target;

        let el = e.target.closest('button, a, input, select, textarea, label, [role="button"], [role="checkbox"], [role="radio"], [role="option"], [role="combobox"], [role="menuitem"], [role="tab"], option, vaadin-item, vaadin-combo-box-item, [class*="item"], [class*="option"], [onclick], [tabindex]');
        if (!el && inner && inner.closest) {
            el = inner.closest('button, a, input, select, textarea, label, [role="button"], [role="checkbox"], [role="radio"], [role="option"], [role="combobox"], [role="menuitem"], [role="tab"], option, vaadin-item, vaadin-combo-box-item, [class*="item"], [class*="option"], [onclick], [tabindex]');
        }
        if (!el && e.target?.tagName?.includes('-')) {
            el = e.target;
        }
        if (!el) return;

        // If clicked on a label, resolve to its target input/checkbox if available
        if (el.tagName === 'LABEL') {
            const controlled = el.control || (el.htmlFor ? document.getElementById(el.htmlFor) : null) || el.querySelector('input, select, textarea');
            if (controlled) {
                el = controlled;
            }
        }
        
        // Anti-double-click: only ignore if it's the SAME element clicked within 300ms
        if (now - lastClickAt < 300 && window.__lastClickedElement === el) return;
        
        if (window.getComputedStyle(el).pointerEvents === 'none') return;

        // Skip recording click on text fields (handled via change/fill)
        const isTextField = (el.tagName === 'INPUT' && ['text', 'password', 'email', 'number', 'search', 'tel', 'url'].includes(el.type)) ||
            el.tagName.toLowerCase().includes('text-field') ||
            el.tagName.toLowerCase().includes('password-field') ||
            el.tagName.toLowerCase().includes('email-field') ||
            el.tagName.toLowerCase().includes('number-field');
        if (isTextField) return;

        lastClickAt = now;
        window.__lastClickedElement = el;
        const selector = getBestSelector(el);

        let label = el.innerText?.trim().split('\n')[0];
        if (!label) {
            const img = el.querySelector('img');
            if (img && img.alt) label = img.alt;
        }
        if (!label) {
            label = extractFieldLabel(el);
        }
        if (!label) label = el.placeholder || el.getAttribute('aria-label') || el.name || el.title || "Clique";

        if (label.length > 40) label = label.substring(0, 37) + "...";

        captureInteraction({
            action: 'click',
            selector,
            text: label,
            tagName: el.tagName,
            timestamp: now
        });
    }, true);

    // 3. Right-Click Assertions
    document.addEventListener('contextmenu', (e) => {
        if (!isRecording) return;
        
        const path = (e.composedPath && e.composedPath()) || [];
        const inner = path[0] || e.target;
        const el = (e.target?.tagName?.includes('-') && e.target) || inner || e.target;

        // Require it to be a text element or have some value
        let text = el.innerText?.trim() || el.value;
        if (!text || text.length > 100) return; // Don't assert massive blocks of text easily
        
        e.preventDefault(); // Prevent browser context menu
        e.stopPropagation();

        const selector = getBestSelector(el);
        
        captureInteraction({
            action: 'assert',
            operator: 'visible',
            selector,
            value: text,
            label: `Validar Texto: ${text.substring(0, 15)}...`,
            timestamp: Date.now()
        });
        
        showToast(`✅ ${recorderLabels.validationAdded}"${text.substring(0, 20)}"`);
        
    }, true);

    document.addEventListener('change', (e) => {
        if (!isRecording) return;
        const path = (e.composedPath && e.composedPath()) || [];
        const inner = path[0] || e.target;
        const host = e.target;

        const isStandard = ['INPUT', 'SELECT', 'TEXTAREA'].includes(host?.tagName);
        const isShadowInput = ['INPUT', 'SELECT', 'TEXTAREA'].includes(inner?.tagName);
        const isCustom = host?.tagName?.includes('-') && (
            isShadowInput ||
            host.value !== undefined ||
            host.checked !== undefined ||
            (host.shadowRoot && host.shadowRoot.querySelector('input, select, textarea'))
        );

        if (!isStandard && !isShadowInput && !isCustom) return;

        const el = isCustom ? host : (isStandard ? host : inner);
        const selector = getBestSelector(el);
        
        let label = extractFieldLabel(el);
        if (!label) {
            label = el.placeholder || el.getAttribute('aria-label') || el.name || el.title || "Campo";
        }

        const isCheckbox = inner.type === 'checkbox' || host.type === 'checkbox' || host.tagName?.toLowerCase().includes('checkbox');
        const isSelect = el.tagName === 'SELECT' || host?.tagName === 'SELECT' || inner?.tagName === 'SELECT' || el.tagName?.toLowerCase().includes('select') || host?.tagName?.toLowerCase().includes('select');

        if (isCheckbox) {
            // If already captured by click within last 400ms, skip duplicate
            if (Date.now() - lastClickAt > 400) {
                const isChecked = host.checked !== undefined ? host.checked : (inner.checked !== undefined ? inner.checked : el.checked);
                captureInteraction({
                    action: 'click',
                    selector,
                    text: label,
                    checked: !!isChecked,
                    tagName: el.tagName,
                    timestamp: Date.now()
                });
            }
            return;
        }

        const rawValue = host.value !== undefined ? host.value : inner.value;
        const stringValue = rawValue !== undefined && rawValue !== null ? String(rawValue) : '';

        if (isSelect) {
            let selectedText = '';
            const selectEl = el.tagName === 'SELECT' ? el : (host?.tagName === 'SELECT' ? host : null);
            if (selectEl && selectEl.selectedIndex >= 0) {
                selectedText = selectEl.options[selectEl.selectedIndex]?.text?.trim() || '';
            }
            captureInteraction({
                action: 'select',
                selector,
                value: stringValue,
                selectedText: selectedText || stringValue,
                label: label,
                timestamp: Date.now()
            });
            return;
        }

        captureInteraction({
            action: 'fill',
            selector,
            value: stringValue,
            label: label,
            timestamp: Date.now()
        });
    }, true);

    document.addEventListener('keydown', (e) => {
        if (!isRecording) return;
        if (e.key === 'Enter') {
            const path = (e.composedPath && e.composedPath()) || [];
            const inner = path[0] || e.target;
            const host = e.target;

            const isStandard = ['INPUT', 'TEXTAREA'].includes(host?.tagName);
            const isShadow = ['INPUT', 'TEXTAREA'].includes(inner?.tagName);
            const isCustom = host?.tagName?.includes('-') && (isShadow || host.value !== undefined);

            if (!isStandard && !isShadow && !isCustom) return;

            const el = isCustom ? host : (isStandard ? host : inner);
            const selector = getBestSelector(el);
            captureInteraction({
                action: 'keypress',
                selector,
                value: 'Enter',
                label: 'Press Enter',
                timestamp: Date.now()
            });
        }
    }, true);

    // FETCH Interceptor
    const originalFetch = window.fetch;
    window.fetch = async function (...args) {
        const fetchPromise = originalFetch.apply(this, args);
        if (!isRecording) return fetchPromise;

        try {
            const reqArg = args[0];
            const optArg = args[1] || {};
            let url, method, headers = {}, body = null;

            if (reqArg instanceof Request) {
                url = reqArg.url;
                method = reqArg.method;
                reqArg.headers.forEach((v, k) => { headers[k] = v; });
                if (['POST', 'PUT', 'PATCH'].includes(method.toUpperCase())) {
                    try { body = await reqArg.clone().text(); } catch (e) { }
                }
            } else {
                url = String(reqArg);
                method = (optArg.method || 'GET').toUpperCase();
                if (optArg.headers) {
                    if (optArg.headers instanceof Headers) optArg.headers.forEach((v, k) => { headers[k] = v; });
                    else if (Array.isArray(optArg.headers)) optArg.headers.forEach(([k, v]) => { headers[k] = v; });
                    else headers = optArg.headers;
                }
                body = await normalizeBody(optArg.body);
            }
            
            // Mask password in JSON payload
            if (body && typeof body === 'string' && body.includes('password')) {
                try {
                    let parsed = JSON.parse(body);
                    const maskJson = (obj) => {
                        for (let k in obj) {
                            if (k.toLowerCase().includes('password') || k.toLowerCase().includes('senha')) {
                                obj[k] = "***MASKED***";
                            } else if (typeof obj[k] === 'object' && obj[k] !== null) {
                                maskJson(obj[k]);
                            }
                        }
                    };
                    maskJson(parsed);
                    body = JSON.stringify(parsed);
                } catch(e) {}
            }

            const absUrl = new URL(url, window.location.href).href;
            if (!absUrl.match(/\.(js|css|png|jpe?g|gif|svg|webp|woff2?|ico|map)$/i)) {
                captureRequest({ method, url: absUrl, headers, body, timestamp: Date.now() });
            }
        } catch (e) { }
        return fetchPromise;
    };

    // XHR Interceptor
    const originalXHROpen = XMLHttpRequest.prototype.open;
    const originalXHRSend = XMLHttpRequest.prototype.send;
    const originalXHRHeader = XMLHttpRequest.prototype.setRequestHeader;

    XMLHttpRequest.prototype.setRequestHeader = function (h, v) {
        if (!this._caps) this._caps = { headers: {} };
        this._caps.headers[h] = v;
        return originalXHRHeader.apply(this, arguments);
    };

    XMLHttpRequest.prototype.open = function (m, u) {
        if (!this._caps) this._caps = { headers: {} };
        this._caps.method = m;
        try { this._caps.url = new URL(u, window.location.href).href; } catch (e) { this._caps.url = u; }
        return originalXHROpen.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function (body) {
        this.addEventListener('load', async () => {
            if (!isRecording || !this._caps?.url) return;
            if (!this._caps.url.match(/\.(js|css|png|jpe?g|gif|svg|webp|woff2?|ico|map)$/i)) {
                let capturedBody = await normalizeBody(body);
                // Mask password in XHR payload
                if (capturedBody && typeof capturedBody === 'string' && capturedBody.includes('password')) {
                    try {
                        let parsed = JSON.parse(capturedBody);
                        const maskJson = (obj) => {
                            for (let k in obj) {
                                if (k.toLowerCase().includes('password') || k.toLowerCase().includes('senha')) {
                                    obj[k] = "***MASKED***";
                                } else if (typeof obj[k] === 'object' && obj[k] !== null) {
                                    maskJson(obj[k]);
                                }
                            }
                        };
                        maskJson(parsed);
                        capturedBody = JSON.stringify(parsed);
                    } catch(e) {}
                }
                
                captureRequest({ method: this._caps.method.toUpperCase(), url: this._caps.url, headers: this._caps.headers, body: capturedBody, timestamp: Date.now() });
            }
        });
        return originalXHRSend.apply(this, arguments);
    };

    // 4. Auto-Capture Title Changes
    let lastRecordedTitle = document.title;
    const titleObserver = new MutationObserver(() => {
        if (!isRecording) return;
        if (document.title && document.title !== lastRecordedTitle) {
            lastRecordedTitle = document.title;
            captureInteraction({
                action: 'assert',
                operator: 'equals',
                selector: 'document.title',
                value: lastRecordedTitle,
                label: `Validar Título: ${lastRecordedTitle.substring(0, 20)}`,
                timestamp: Date.now()
            });
            showToast(`✅ ${recorderLabels.titleCaptured}"${lastRecordedTitle.substring(0, 20)}"`);
        }
    });
    
    const observeTitle = () => {
        const titleEl = document.querySelector('title');
        if (titleEl) {
            titleObserver.observe(titleEl, { subtree: true, characterData: true, childList: true });
        } else if (document.head) {
            titleObserver.observe(document.head, { subtree: true, characterData: true, childList: true });
        }
    };
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        observeTitle();
    } else {
        document.addEventListener('DOMContentLoaded', observeTitle);
    }

    // 5. Auto-Capture Modals / Toasts
    let lastModalText = "";
    let lastModalTime = 0;
    const modalObserver = new MutationObserver((mutations) => {
        if (!isRecording) return;
        const now = Date.now();
        
        for (const m of mutations) {
            for (const node of m.addedNodes) {
                if (node.nodeType !== Node.ELEMENT_NODE) continue;
                
                const text = node.innerText?.trim();
                if (!text || text.length > 200 || text.length < 3) continue;
                
                // Avoid firing for the Flow recorder's own toasts/banners
                if (node.id === 'flow-status-indicator' || 
                    node.getAttribute?.('data-flow-recorder') === 'true' || 
                    node.querySelector?.('[data-flow-recorder]')) continue;
                
                const html = node.outerHTML.toLowerCase();
                const isModalOrToast = 
                    html.includes('toast') || html.includes('snackbar') || 
                    html.includes('modal') || html.includes('alert') || 
                    html.includes('notification') || html.includes('message') ||
                    node.getAttribute('role') === 'alert' ||
                    node.getAttribute('role') === 'dialog' ||
                    node.getAttribute('role') === 'status';
                    
                if (isModalOrToast) {
                    const isSuccessOrError = 
                        html.includes('success') || html.includes('sucesso') || 
                        html.includes('error') || html.includes('erro') ||
                        html.includes('fail') || html.includes('falha') ||
                        html.includes('warning') || html.includes('aviso');
                        
                    if (isSuccessOrError) {
                        if (text === lastModalText && (now - lastModalTime < 2000)) continue;
                        
                        lastModalText = text;
                        lastModalTime = now;
                        
                        const selector = getBestSelector(node);
                        captureInteraction({
                            action: 'assert',
                            operator: 'visible',
                            selector: selector,
                            value: text,
                            label: `Validar Modal: ${text.substring(0, 15)}...`,
                            timestamp: Date.now()
                        });
                        showToast(`✅ ${recorderLabels.modalCaptured}"${text.substring(0, 20)}"`);
                        return; // Only capture one per batch
                    }
                }
            }
        }
    });
    
    const observeBody = () => {
        if (document.body) {
            modalObserver.observe(document.body, { childList: true, subtree: true });
        }
    };
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        observeBody();
    } else {
        document.addEventListener('DOMContentLoaded', observeBody);
    }

})();
