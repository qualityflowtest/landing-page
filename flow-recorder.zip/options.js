document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('saveBtn').addEventListener('click', saveOptions);

function getI18nText(key, defaultText) {
    if (window.i18n && typeof window.i18n.getMessage === 'function') {
        const text = window.i18n.getMessage(key);
        if (text && text !== key) return text;
    }
    return defaultText;
}

function showStatus(msg, isSuccess) {
    const statusEl = document.getElementById('status');
    statusEl.textContent = msg;
    statusEl.className = isSuccess ? 'status-success' : 'status-error';
    setTimeout(() => {
        statusEl.className = '';
    }, 5000);
}

function restoreOptions() {
    chrome.storage.sync.get({
        apiUrl: 'http://localhost:8000',
        email: ''
    }, function(items) {
        document.getElementById('apiUrl').value = items.apiUrl;
        document.getElementById('email').value = items.email;
        // Password and Token are not restored to UI for security
    });
}

async function saveOptions() {
    const apiUrl = document.getElementById('apiUrl').value.replace(/\/$/, '');
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const saveBtn = document.getElementById('saveBtn');

    if (!apiUrl || !email || !password) {
        showStatus(getI18nText('msgFillAll', 'Please fill in all fields.'), false);
        return;
    }

    saveBtn.disabled = true;
    saveBtn.textContent = getI18nText('btnVerifying', 'Verifying...');

    try {
        const response = await fetch(`${apiUrl}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: email,
                password: password
            })
        });

        if (!response.ok) {
            let errorDetail = 'Login failed';
            try {
                const data = await response.json();
                errorDetail = data.detail || errorDetail;
            } catch (_) {}
            throw new Error(errorDetail);
        }

        const data = await response.json();
        const token = data.access_token;

        chrome.storage.sync.set({
            apiUrl: apiUrl,
            email: email,
            token: token
        }, function() {
            // Also update local storage for immediate notification to background.js & popup.js
            chrome.storage.local.set({
                authToken: token,
                apiUrl: apiUrl
            }, function() {
                showStatus(getI18nText('msgSavedSuccess', 'Settings saved and verified successfully!'), true);
                document.getElementById('password').value = '';
            });
        });
    } catch (err) {
        showStatus(getI18nText('msgError', 'Error: ') + (err.message || 'Error'), false);
    } finally {
        saveBtn.disabled = false;
        saveBtn.textContent = getI18nText('btnVerifySave', 'Verify & Save');
    }
}
