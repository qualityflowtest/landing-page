// Arquivo de Configuração da Extensão Flow QA
// A URL agora é configurável pela página de Opções (options.html)

const DEFAULT_CONFIG = {
    API_BASE_URL: "http://localhost:8000"
};

async function getConfig() {
    return new Promise((resolve) => {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
            chrome.storage.sync.get(['apiUrl', 'token'], function(items) {
                resolve({
                    API_BASE_URL: items.apiUrl || DEFAULT_CONFIG.API_BASE_URL,
                    TOKEN: items.token || null
                });
            });
        } else {
            resolve({
                API_BASE_URL: DEFAULT_CONFIG.API_BASE_URL,
                TOKEN: null
            });
        }
    });
}

// Se estiver rodando em Service Worker (Background)
if (typeof self !== 'undefined') {
    self.getConfig = getConfig;
}
