// Background Service Worker (V2.0.0)
// High Reliability Version - Use Storage as Source of Truth
try {
    importScripts('config.js');
} catch (e) {
    console.warn("[Flow Recorder] Failed to load config.js");
}

console.log("[Flow Recorder] Background Worker V2.0.0 active");

chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.sync.get(['token', 'apiUrl'], (syncItems) => {
        chrome.storage.local.set({
            isRecording: false,
            capturedInteractions: [],
            capturedRequests: [],
            currentNodeName: "",
            authToken: syncItems?.token || null,
            apiUrl: syncItems?.apiUrl || "http://localhost:8000"
        });
    });
});

// Restore auth credentials from sync storage on worker startup
chrome.storage.sync.get(['token', 'apiUrl'], (syncItems) => {
    if (syncItems && syncItems.token) {
        chrome.storage.local.set({
            authToken: syncItems.token,
            apiUrl: syncItems.apiUrl || "http://localhost:8000"
        });
    }
});

// Keep local storage in sync whenever sync storage changes
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'sync') {
        if (changes.token) {
            chrome.storage.local.set({ authToken: changes.token.newValue || null });
        }
        if (changes.apiUrl) {
            chrome.storage.local.set({ apiUrl: changes.apiUrl.newValue || "http://localhost:8000" });
        }
    }
});

function updateBadge(count) {
    chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
    chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
}

async function injectToTab(tabId) {
    try {
        const state = await chrome.storage.local.get(['isRecording']);
        if (!state.isRecording) return;

        // Ensure content.js is present (idempotent guard in content.js prevents duplicates)
        await chrome.scripting.executeScript({
            target: { tabId, allFrames: true },
            files: ['content.js']
        }).catch(() => { });

        // Inject recorder engine into MAIN page world
        await chrome.scripting.executeScript({
            target: { tabId, allFrames: true },
            world: 'MAIN',
            files: ['inject.js']
        });

        chrome.tabs.sendMessage(tabId, { type: "ENABLE_INTERCEPTOR" }).catch(() => { });
    } catch (e) { }
}

// Memory cache for sub-second deduplication only
let lastReqHash = "";
let lastReqTime = 0;
let lastInterKey = "";
let lastInterTime = 0;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.type) return false;

    // A. Interceptor Management
    if (message.type === "NEW_INTERACTION") {
        const data = message.data;
        const now = Date.now();
        const key = `${data.action}:${data.selector}:${data.value}:${data.text}`;

        if (lastInterKey === key && (now - lastInterTime < 400)) return false;
        lastInterKey = key;
        lastInterTime = now;

        chrome.storage.local.get(['isRecording', 'capturedInteractions', 'currentNodeName'], (res) => {
            if (!res.isRecording) return;
            const list = res.capturedInteractions || [];
            const inter = {
                ...data,
                customNodeName: res.currentNodeName || null,
                pageTitle: sender.tab?.title || "Página",
                pageUrl: sender.tab?.url || ""
            };
            list.push(inter);
            chrome.storage.local.set({ capturedInteractions: list }, () => {
                updateBadge(list.length);
                console.log(`[Flow] Interação #${list.length} salva no storage.`);
            });
        });
        return false;
    }

    if (message.type === "NEW_REQUEST") {
        const data = message.data;
        const now = Date.now();
        const requestHash = `${data.method}:${data.url}:${data.body || ''}`;

        if (lastReqHash === requestHash && (now - lastReqTime < 100)) return false;
        lastReqHash = requestHash;
        lastReqTime = now;

        chrome.storage.local.get(['isRecording', 'capturedRequests', 'currentNodeName'], (res) => {
            if (!res.isRecording) return;
            const list = res.capturedRequests || [];
            const req = {
                ...data,
                customNodeName: res.currentNodeName || null,
                pageTitle: sender.tab?.title || "Página",
                pageUrl: sender.tab?.url || ""
            };
            list.push(req);
            chrome.storage.local.set({ capturedRequests: list });
        });
        return false;
    }

    // B. Control Commands
    if (message.type === "START_RECORDING") {
        chrome.storage.local.set({
            isRecording: true,
            capturedInteractions: [],
            capturedRequests: [],
            currentNodeName: ""
        }, () => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                tabs.forEach(tab => {
                    if (tab.url?.startsWith('http://') || tab.url?.startsWith('https://')) injectToTab(tab.id);
                });
            });
            updateBadge(0);
            sendResponse({ success: true });
        });
        return true;
    }

    if (message.type === "STOP_RECORDING") {
        chrome.storage.local.set({ isRecording: false }, () => {
            chrome.tabs.query({}, (tabs) => {
                tabs.forEach(tab => {
                    if (tab.url?.startsWith('http://') || tab.url?.startsWith('https://')) {
                        chrome.tabs.sendMessage(tab.id, { type: "DISABLE_INTERCEPTOR" }).catch(() => { });
                    }
                });
            });
            chrome.storage.local.get(['capturedInteractions'], (res) => {
                sendResponse({ success: true, count: (res.capturedInteractions || []).length });
            });
        });
        return true;
    }

    if (message.type === "GET_STATUS") {
        chrome.storage.local.get(['isRecording', 'capturedInteractions', 'capturedRequests', 'currentNodeName', 'authToken'], (res) => {
            sendResponse({
                isRecording: !!res.isRecording,
                interactionCount: (res.capturedInteractions || []).length,
                interactions: res.capturedInteractions || [],
                requests: res.capturedRequests || [],
                currentNodeName: res.currentNodeName || "",
                authToken: res.authToken || null
            });
        });
        return true;
    }

    if (message.type === "SET_TOKEN") {
        chrome.storage.local.set({ authToken: message.token }, () => {
            chrome.storage.sync.set({ token: message.token });
            console.log("[Flow] Auth Token atualizado.");
            sendResponse({ success: true });
        });
        return true;
    }

    if (message.type === "CLEAR_DATA") {
        chrome.storage.local.set({ capturedInteractions: [], capturedRequests: [], currentNodeName: "" }, () => {
            updateBadge(0);
            sendResponse({ success: true });
        });
        return true;
    }

    if (message.type === "SET_NODE_NAME") {
        chrome.storage.local.set({ currentNodeName: message.name }, () => {
            sendResponse({ success: true });
        });
        return true;
    }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && (tab.url?.startsWith('http://') || tab.url?.startsWith('https://'))) {
        injectToTab(tabId);
    }
});

// Capture Classic Document Form Submissions (Non-AJAX)
if (chrome.webRequest && chrome.webRequest.onBeforeRequest) {
    chrome.webRequest.onBeforeRequest.addListener(
        (details) => {
            // Only capture main_frame (full page) navigations that are NOT simple GETs
            if (details.type === 'main_frame' && details.method !== 'GET' && !details.url.startsWith('chrome-extension://')) {
                chrome.storage.local.get(['isRecording', 'capturedRequests', 'currentNodeName'], (res) => {
                    if (!res.isRecording) return;
                    
                    let body = null;
                    if (details.requestBody) {
                        if (details.requestBody.formData) {
                            body = JSON.stringify(details.requestBody.formData);
                        } else if (details.requestBody.raw && details.requestBody.raw[0].bytes) {
                            try {
                                body = new TextDecoder().decode(details.requestBody.raw[0].bytes);
                            } catch (e) {}
                        }
                    }
                    
                    const req = {
                        method: details.method,
                        url: details.url,
                        headers: {}, // Can't capture headers synchronously here, but method/body/url is enough for classical forms
                        body: body,
                        timestamp: details.timeStamp,
                        customNodeName: res.currentNodeName || null,
                        pageTitle: "Submissão de Formulário",
                        pageUrl: details.url
                    };
                    
                    const list = res.capturedRequests || [];
                    list.push(req);
                    chrome.storage.local.set({ capturedRequests: list });
                });
            }
        },
        { urls: ["<all_urls>"] },
        ["requestBody"]
    );
}
